The census boundary data is available from Statistics Canada (https://www12.statcan.gc.ca/census-recensement/2021/geo/sip-pis/boundary-limites/)

The subway line data was filtered from Open Data from Metrolinx

